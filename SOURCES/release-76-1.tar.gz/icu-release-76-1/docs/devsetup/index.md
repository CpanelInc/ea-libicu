---
layout: default
title: Setup for Contributors
nav_order: 10000
has_children: true
---

<!--
© 2016 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# Setup for Contributors

