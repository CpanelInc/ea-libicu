---
layout: default
title: Misc
nav_order: 15
has_children: true
---
<!--
© 2020 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# Development

Top-level page for topics for ICU developers. See the subpages listed below for
details:

[Coding Guidelines](codingguidelines.md)

[Contributions to the ICU library](contributions.md)

[Synchronization Issues](sync/index.md)