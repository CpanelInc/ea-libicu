<!--
© 2020 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# Normalization Examples (Obsolete)

## This page contained examples showing obsolete APIs

The examples have been removed, and updated examples added to the main [Normalization page](index.md).
