---
layout: default
title: IO
nav_order: 11
has_children: true
---
<!--
© 2020 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# ICU IO

The ICU I/O (Unicode stdio) Library is an optional library that provides a stdio like API with Unicode support.

